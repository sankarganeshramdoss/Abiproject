<html>
<style>
table, th, td {
  border: 1px solid black;
  text-align: center;
  table-layout: center;
}
#table1 {
	width: 1%;
	height: 50px;
	text-align: center;
	border-collapse: collapse;
    width: 100%;
    table-layout:center;
    
}
#table2 {
	width: 10%;
	height: 30px;
	text-align: center;
	table-layout: center;
}
</style>
</head>
<body>
<center>
<table id="table1"><tr><td><img src="F:\Backup\sankar\Desktop\New folder (4)\krishna 10.jpg" alt="krishna 10.jpg " style="width:200px;height:200px;margin-left:15px;text-align: center">
<center>
<table id="table2">
  <tr>
    <td>Name</td>
    <td>Abirami.S</td>
  </tr>
  <tr>
    <td>Date of birth</td>
    <td>16.04.2008</td>
  </tr>
  <tr>
    <td>Gender</td>
    <td>Female</td>
  </tr>
  <tr>
    <td>Religion</td>
    <td>hindu</td>
  </tr>
  <tr>
    <td>Community</td>
    <td>Bc</td>
  </tr>
  <tr>
    <td>Caste</td>
    <td>Kasukara chettiyar</td>
  </tr>
  <tr>
    <td>Address</td>
    <td>58</td>
  </tr>
  <tr>
    <td>Address1</td>
    <td>Joseph Nagar</td>
  </tr>
  <tr>
    <td>Address2</td>
    <td>Thirunagar</td>
  </tr>
  <tr>
    <td>City</td>
    <td>Madurai</td>
  </tr>
  <tr>
    <td>Mobile 1</td>
    <td>9994073242</td>
  </tr>
  <tr>
    <td>Mobile 2</td>
    <td>7010242516</td>
  </tr>
</table>
</td></tr></table>